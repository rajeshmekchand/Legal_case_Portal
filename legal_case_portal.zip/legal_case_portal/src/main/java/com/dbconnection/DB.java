package com.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
//    private static String url;
//	private static DB db_instance;
//	private DB() {
//
//		String driver = null;
//		try {
//			ResourceBundle bundle = ResourceBundle.getBundle("db");
//			driver = bundle.getString("jdbc.driver");
//			Class.forName(driver);
//			url = bundle.getString("jdbc.url");
//		} catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public static Connection getConnection() throws SQLException {
//
//		if (db_instance == null) {
//			db_instance = new DB();
//		}
//		try {
//			return DriverManager.getConnection(db_instance.url);
//		} catch (SQLException e) {
//			throw e;
//		}
//	}
//	public static void closeConnection(Connection connection) {
//		try {
//			if (connection != null) {
//				connection.close();
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//	}

	static String URL = "localhost:3306/";
	static String DATABASE_NAME = "nict_legal_case_portal";
	static String USERNAME = "root";
	static String PASSWORD = "1234";

	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nict_legal_case_portal", "root", "1234");
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		return con;
	}

	public static void closeConnection(Connection con) {
		// TODO Auto-generated method stub

	}

}
