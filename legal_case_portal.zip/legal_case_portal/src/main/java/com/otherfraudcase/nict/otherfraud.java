package com.otherfraudcase.nict;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 * Servlet implementation class o_fraudentity
 */

@WebServlet(name = "Otherfraud", urlPatterns = { "/Otherfraud" })

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB
		maxFileSize = 1024 * 1024 * 1000, // 1 GB
		maxRequestSize = 1024 * 1024 * 1000) // 1 GB
public class otherfraud extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public otherfraud() {
		super();
		// TODO Auto-generated constructor stub
	}

	PrintWriter out = null;
	Connection con;
	PreparedStatement pst;
	HttpSession session = null;
	int row;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/plain;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try {

			out = response.getWriter();
			session = request.getSession(false);
			con = com.dbconnection.DB.getConnection();

			String folderName = "resources";
			String uploadPath = request.getServletContext().getRealPath("/") + folderName;
			System.out.println(uploadPath);
			File dir = new File(uploadPath);
			if (!dir.exists()) {
				dir.mkdirs();
			}

			Part file1 = request.getPart("legalnotice");
			Random rand = new Random();

			// Generate random integers in range in 5 digit
			int uniqueID = rand.nextInt(100000);

			String name = request.getParameter("name");
			String bank = request.getParameter("bank");

			String place = request.getParameter("place");
			String state = request.getParameter("state");
			String legalnotice = file1.getSubmittedFileName();
			String date_of_notice = request.getParameter("date_of_notice");
			String amount_involved = request.getParameter("amount_involved");
			String amount_settled = request.getParameter("amount_settled");
			String legal_notice_reply = request.getParameter("legal_notice_reply");

			String path1 = folderName + File.separator + legalnotice;

			InputStream isNew = file1.getInputStream();
			Files.copy(isNew, Paths.get(uploadPath + File.separator + legalnotice),
					StandardCopyOption.REPLACE_EXISTING);

			InputStream is1New = file1.getInputStream();
			Files.copy(is1New, Paths.get(uploadPath + File.separator + legalnotice),
					StandardCopyOption.REPLACE_EXISTING);

			System.out.println("Hello");
			int status = 0;
			pst = con.prepareStatement(
					"insert into other_fraud_case(uniqueID,name,bank,place,state,legalnotice,date_of_notice,amount_involved,amount_settled,legal_notice_reply)values(?,?,?,?,?,?,?,?,?,?)");
			pst.setInt(1, uniqueID);
			pst.setString(2, name);
			pst.setString(3, bank);

			pst.setString(4, place);
			pst.setString(5, state);
			pst.setString(6, legalnotice);
			pst.setString(7, date_of_notice);
			pst.setString(8, amount_involved);
			pst.setString(9, amount_settled);
			pst.setString(10, legal_notice_reply);

			status = pst.executeUpdate();
			out.println("Record Added");
			response.sendRedirect("apicall.jsp");

			if (status > 0) {
				session.setAttribute("legalnotice", legalnotice);
				String msg9 = "" + legalnotice + " Record upload successfully...";
				request.setAttribute("msg9", msg9);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
}
