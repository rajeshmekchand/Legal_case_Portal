package com.legalhistory.copy;



public class history {
	private int id_history;
	private int cs_id;
	private String new_chs;
	public history() {
		super();
		// TODO Auto-generated constructor stub
	}
	public history(int id_history, int cs_id, String new_chs) {
		super();
		this.id_history = id_history;
		this.cs_id = cs_id;
		this.new_chs = new_chs;
	}
	public int getId_history() {
		return id_history;
	}
	public void setId_history(int id_history) {
		this.id_history = id_history;
	}
	public int getCs_id() {
		return cs_id;
	}
	public void setCs_id(int cs_id) {
		this.cs_id = cs_id;
	}
	public String getNew_chs() {
		return new_chs;
	}
	public void setNew_chs(String new_chs) {
		this.new_chs = new_chs;
	}
	@Override
	public String toString() {
		return "history [id_history=" + id_history + ", cs_id=" + cs_id + ", new_chs=" + new_chs + "]";
	}

}
