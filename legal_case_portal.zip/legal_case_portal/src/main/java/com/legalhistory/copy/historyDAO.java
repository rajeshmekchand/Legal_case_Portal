package com.legalhistory.copy;

public interface historyDAO {



}
