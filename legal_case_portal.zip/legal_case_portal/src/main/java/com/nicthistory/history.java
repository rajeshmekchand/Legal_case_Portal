package com.nicthistory;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/history")
public class history extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public history() {
		super();
		// TODO Auto-generated constructor stub
	}

	PrintWriter out = null;
	Connection con;
	PreparedStatement pst;
	HttpSession session = null;
	int row;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request,response);
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println(" doGet history servlet");


		//response.setContentType("text/plain;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try {

			out = response.getWriter();
			session = request.getSession(false);
			con = com.dbconnection.DB.getConnection();

			String cs_id = request.getParameter("cs_id");
			String new_chs = request.getParameter("new_chs");
			System.out.println(" doGet historyServlet cs_id : "+ cs_id);
			System.out.println(" doGet historyServlet new_chs : "+ new_chs);

			int status = 0;
			pst = con.prepareStatement("insert into case_history(cs_id,new_chs)values(?,?)");
			pst.setString(1, cs_id);
			pst.setString(2, new_chs);

			status = pst.executeUpdate();
			out.println("Record Added");
			response.sendRedirect("apicall.jsp");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
