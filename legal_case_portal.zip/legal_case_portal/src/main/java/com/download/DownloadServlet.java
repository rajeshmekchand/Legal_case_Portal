package com.download;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet(name = "DownloadServlet", urlPatterns = { "/DownloadServlet" })
public class DownloadServlet extends HttpServlet {
	public static int BUFFER_SIZE = 1024 * 100;
	public static final String UPLOAD_DIR = "resources";
	public static String photo = null;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/**
		 * * Get The Absolute Path Of The File To Be Downloaded **
		 */
		String photo = request.getParameter("photo");
		String new_documents = request.getParameter("new_documents");

		if (photo == null || photo.equals("")) {
			/**
			 * * Set Response Content Type **
			 */
			response.setContentType("text/html");

			/**
			 * * Print The Response **
			 */
			response.getWriter().println("<h3>File " + photo + " Is Not Present .....!</h3>");
		} else {
			String applicationPath = getServletContext().getRealPath("/");
			String downloadPath = applicationPath + UPLOAD_DIR;

			System.out.println("downloadpath: " + downloadPath);
			String filePath = downloadPath + File.separator + photo;
			System.out.println(photo);
			System.out.println(filePath);
			System.out.println("photo:" + photo);
			System.out.println("filePath :" + filePath);
			File file = new File(filePath);
			OutputStream outStream = null;
			FileInputStream inputStream = null;

			if (file.exists()) {

				/**
				 * ** Setting The Content Attributes For The Response Object *
				 */

				/**
				 * ** Setting The Content Attributes For The Response Object *
				 */

				String d = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date());
				String downloadFileName = d.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "") + ".jpg";
				response.setContentType("text/plain");
				response.setHeader("Content-disposition", "attachment; photo = " + downloadFileName);
				try {

					/**
					 * * Get The Output Stream Of The Response **
					 */
					outStream = response.getOutputStream();
					inputStream = new FileInputStream(file);
					byte[] buffer = new byte[BUFFER_SIZE];
					int bytesRead = -1;
					/**
					 * ** Write Each Byte Of Data Read From The Input Stream Write Each Byte Of Data
					 * Read From The Input Stream Into The Output Stream *
					 */
					while ((bytesRead = inputStream.read(buffer)) != -1) {
						outStream.write(buffer, 0, bytesRead);
					}
				} catch (IOException ioExObj) {
					System.out.println("Exception While Performing The I/O Operation?= " + ioExObj.getMessage());
				} finally {
					if (inputStream != null) {
						inputStream.close();
					}
					outStream.flush();
					if (outStream != null) {
						outStream.close();
					}
				}
			} else {
				/**
				 * * Set Response Content Type **
				 */
				response.setContentType("text/html");
				/**
				 * * Print The Response **
				 */
				response.getWriter().println("<h3>File " + photo + " Is Not Present .....!</h3>");
			}
		}

		/* show new documents */
		if (new_documents == null || new_documents.equals(""))

		{
			/**
			 * * Set Response Content Type **
			 */
			response.setContentType("text/html");

			/**
			 * * Print The Response **
			 */
			response.getWriter().println("<h3>File " + new_documents + " Is Not Present .....!</h3>");
		} else {
			String applicationPath = getServletContext().getRealPath("/");
			String downloadPath = applicationPath + UPLOAD_DIR;

			System.out.println("downloadpath: " + downloadPath);
			String filePath = downloadPath + File.separator + new_documents;
			System.out.println(new_documents);
			System.out.println(filePath);
			System.out.println("new documents:" + new_documents);
			System.out.println("filePath :" + filePath);
			File file = new File(filePath);
			OutputStream outStream = null;
			FileInputStream inputStream = null;

			if (file.exists()) {

				/**
				 * ** Setting The Content Attributes For The Response Object *
				 */

				/**
				 * ** Setting The Content Attributes For The Response Object *
				 */

				String d = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date());
				String downloadFileName = d.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "") + ".jpg";
				response.setContentType("text/plain");
				response.setHeader("Content-disposition", "attachment; new_documents = " + downloadFileName);
				try {

					/**
					 * * Get The Output Stream Of The Response **
					 */
					outStream = response.getOutputStream();
					inputStream = new FileInputStream(file);
					byte[] buffer = new byte[BUFFER_SIZE];
					int bytesRead = -1;
					/**
					 * ** Write Each Byte Of Data Read From The Input Stream Write Each Byte Of Data
					 * Read From The Input Stream Into The Output Stream *
					 */
					while ((bytesRead = inputStream.read(buffer)) != -1) {
						outStream.write(buffer, 0, bytesRead);
					}
				} catch (IOException ioExObj) {
					System.out.println("Exception While Performing The I/O Operation?= " + ioExObj.getMessage());
				} finally {
					if (inputStream != null) {
						inputStream.close();
					}
					outStream.flush();
					if (outStream != null) {
						outStream.close();
					}
				}
			} else {
				/**
				 * * Set Response Content Type **
				 */
				response.setContentType("text/html");
				/**
				 * * Print The Response **
				 */
				response.getWriter().println("<h3>File " + new_documents + " Is Not Present .....!</h3>");
			}
		}

	}
}