package com.editlegalcase.nict;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet(name = "editlegal", urlPatterns = { "/editlegal" })

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB
		maxFileSize = 1024 * 1024 * 1000, // 1 GB
		maxRequestSize = 1024 * 1024 * 1000) // 1 GB
public class editlegal extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public editlegal() {
		super();
		// TODO Auto-generated constructor stub
	}

	PrintWriter out = null;
	Connection con;
	PreparedStatement pst;
	HttpSession session = null;
	int row;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/plain;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try {

			out = response.getWriter();
			session = request.getSession(false);
			con = com.dbconnection.DB.getConnection();

			String folderName = "resources";
			String uploadPath = request.getServletContext().getRealPath("/") + folderName;
			System.out.println(uploadPath);
			File dir = new File(uploadPath);
			if (!dir.exists()) {
				dir.mkdirs();
			}

			Part file1 = request.getPart("new_documents");

			String new_documents = file1.getSubmittedFileName();
			String court_type = request.getParameter("court_type");
			String case_number = request.getParameter("case_number");
			String party_case = request.getParameter("party_case");
			String old_chs = request.getParameter("old_chs");
			String new_chs = request.getParameter("new_chs");
			String path1 = folderName + File.separator + new_documents;

			InputStream isNew = file1.getInputStream();
			Files.copy(isNew, Paths.get(uploadPath + File.separator + new_documents),
					StandardCopyOption.REPLACE_EXISTING);

			InputStream is1New = file1.getInputStream();
			Files.copy(is1New, Paths.get(uploadPath + File.separator + new_documents),
					StandardCopyOption.REPLACE_EXISTING);

			System.out.println("Hello");
			int status = 0;

			pst = con.prepareStatement(
					"insert into legal_case(new_documents,court_type,case_number,party_case,old_chs,new_chs)values(?,?,?,?,?,?)");
			pst.setString(31, new_documents);
			pst.setString(32, court_type);
			pst.setString(33, case_number);
			pst.setString(34, party_case);
			pst.setString(35, old_chs);
			pst.setString(36, new_chs);
			status = pst.executeUpdate();
			out.println("Record Added");
			response.sendRedirect("apicall.jsp");

			if (status > 0) {
				session.setAttribute("new_documents", new_documents);
				String msg9 = "" + new_documents + " Record upload successfully...";
				request.setAttribute("msg9", msg9);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
