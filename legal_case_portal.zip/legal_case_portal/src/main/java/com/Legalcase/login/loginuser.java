package com.Legalcase.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dbconnection.DB;

@WebServlet("/loginuser")
public class loginuser extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public loginuser() {
		super();

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		// Store data in session

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {

			String name = request.getParameter("name");
			String password = request.getParameter("password");

			UserDao udao = new UserDao(DB.getConnection());
			User user = udao.userLogin(name, password);

			if (user != null) {

				System.out.println("login");
				out.print("user login");

				HttpSession session = request.getSession(true);
				session.setAttribute("user", "user");
				response.sendRedirect("apicall.jsp");

			} else {

				out.print("user login Failed");
				out.println("<a href=\"security.jsp\">Kindly Register First</a>");

			}
		}
	}

}
