package com.Legalcase.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;





public class UserDao {

	private Connection connection;
	private String query;
	private PreparedStatement pst;
	private ResultSet rs;

	/*
	 * public UserDao(Connection connection, String query, PreparedStatement pst,
	 * Resultset rs) { super(); this.connection = connection;
	 *
	 * }
	 */

	public UserDao(Connection connection) {
		this.connection = connection;
	}

	public User userLogin(String name, String password) {

		System.out.println(password);

		User user = null;
		try {
			query = "select * from register where name=? and password=?";
			pst = connection.prepareStatement(query);
			/*
			 * String sql = "select * from users where email=? and password=?";
			 * PreparedStatement pst = con.prepareStatement(sql);
			 */
			pst.setString(1, name);
			pst.setString(2, password);

			rs = pst.executeQuery();

			if (rs.next()) {
				user = new User();
				user.setName(rs.getString("name"));
				user.setPassword(rs.getString("password"));

			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());

		}
		return user;

	}

}
