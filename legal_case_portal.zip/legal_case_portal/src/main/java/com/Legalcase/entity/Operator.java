package com.Legalcase.entity;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dbconnection.DB;

@WebServlet(name = "Operator", urlPatterns = { "/Operator" })

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB
		maxFileSize = 1024 * 1024 * 1000, // 1 GB
		maxRequestSize = 1024 * 1024 * 1000) // 1 GB

public class Operator extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Operator() {
		super();
		// TODO Auto-generated constructor stub
	}

	PrintWriter out = null;
	Connection con;
	PreparedStatement pst;
	HttpSession session = null;
	int row;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/plain;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try {

			out = response.getWriter();
			session = request.getSession(false);
			con = DB.getConnection();

			/* Integer serv_id = Integer.parseInt(request.getParameter("serv_id")); */
			String full_name = request.getParameter("full_name");
			String father_name = request.getParameter("father_name");

			String address = request.getParameter("address");
			String village = request.getParameter("village");
			String tehsil = request.getParameter("tehsil");
			String district = request.getParameter("district");
			String division = request.getParameter("division");

			String state = request.getParameter("state");

			int status = 0;


			pst.setString(1, full_name);
			pst.setString(2, father_name);
			pst.setString(3, address);
			pst.setString(4, village);
			pst.setString(5, tehsil);
			pst.setString(6, district);
			pst.setString(7, division);
			pst.setString(8, state);

			status = pst.executeUpdate();
			out.println("Record Added");
			out.println("<a href=\"index.jsp\">Home Page</a>");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
