package com.Legalcase.entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class notification {

	public static void main(String[] args) {
		// Load the JDBC driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return;
		}

		// Connect to the database
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/nict_legal_case_portal","root","1234")) {
			// Retrieve the notification date from the database
			Date notificationDate = getNotificationDateFromDatabase(connection);

			if (notificationDate != null) {
				// Create a Timer instance
				Timer timer = new Timer();

				// Create a TimerTask to represent the notification task
				TimerTask notificationTask = new TimerTask() {
					@Override
					public void run() {
						// This code will be executed when the notification time is reached
						System.out.println("Notification: It's time!");

						// You can add code here to show a GUI notification or perform any other action
					}
				};

				// Schedule the notification task to run at the specified date
				timer.schedule(notificationTask, notificationDate);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static Date getNotificationDateFromDatabase(Connection connection) throws SQLException {
		// Replace the SQL query with your actual query to retrieve the date from the
		// database
		String sql = "SELECT chs FROM your_table WHERE some_condition";

		try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
				ResultSet resultSet = preparedStatement.executeQuery()) {
			if (resultSet.next()) {
				// Assuming the date is stored in a column named "notification_date"
				String dateString = resultSet.getString("notification_date");

				try {
					// Parse the date string to a Date object
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
					return dateFormat.parse(dateString);
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}

		return null;
	}
}
