package com.Legalcase.entity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/search")
public class search extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public search() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");

		 System.setProperty("proxyHost", "192.168.5.4");
		 System.setProperty("proxyPort", "3128");

		String getcritria = request.getParameter("criteria");
		String getvalue = request.getParameter("kopid");

		System.out.println(getcritria + "loan type on javasave");

		if (getcritria != null) {
			JSONObject objcrmsave;
			String jsonInputString = "";

			try {

				objcrmsave = new JSONObject();

				// Gold Loan
				objcrmsave.put("criteria", getcritria);
				objcrmsave.put("value", getvalue);

				/*
				 * System.out.println(objcrmsave + "send req");
				 */// String jsonInputString = new Gson().toJson(arrayObj);
				jsonInputString = objcrmsave.toString();
				System.out.println(jsonInputString + "sam");

			} catch (Exception e) {
				// TODO: handle exception

				System.out.println(e + "e");

			}

			if ((!jsonInputString.equals("")) && (!jsonInputString.equals(null))) {


				String apiUrl = "https://nict.ind.in/nictsales_api/searchSDPByCriteria";


				URL url = new URL(apiUrl);
				System.out.println("Live Url" + url);
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("POST");
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestProperty("Accept", "application/json");
				connection.setRequestProperty("x-api-key", "123456789");
				connection.setDoOutput(true);

				try (OutputStream os = connection.getOutputStream()) {
					byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
					os.write(input, 0, input.length);
				}

				try (BufferedReader br = new BufferedReader(
						new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
					StringBuilder resp = new StringBuilder();
					PrintWriter out = response.getWriter();
					String respLine = null;
					while ((respLine = br.readLine()) != null) {
						resp.append(respLine.trim() + "sam");
//						response.getWriter().write(respLine.trim() + "samjat");
						response.getWriter().flush();

					}

					JSONObject jObj = new JSONObject(resp.toString());
					JSONArray array = jObj.getJSONArray("list");

					for (int i = 0; i < array.length(); i++) {

						JSONObject jObjnew = array.getJSONObject(i);

						request.setAttribute("name", jObjnew.getString("name"));
						request.setAttribute("sdpcode", jObjnew.getString("sdpcode"));
						request.setAttribute("dist", jObjnew.getString("dist"));
						request.setAttribute("state", jObjnew.getString("state"));
						request.setAttribute("pan", jObjnew.getString("pan"));
						request.setAttribute("company", jObjnew.getString("company"));


						System.out.println(jObjnew.getString("name") + " ");
						System.out.println(jObjnew.getString("sdpcode")+ " ");
					    System.out.println(jObjnew.getString("dist"));
					}



					RequestDispatcher rd = request.getRequestDispatcher("legelcase.jsp");

					rd.include(request, response);
					System.out.println(resp.toString() + "End");

				}

			}



		}
	}

}
