package com.Legalcase.entity;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet(name = "Legal", urlPatterns = { "/Legal" })

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB
		maxFileSize = 1024 * 1024 * 1000, // 1 GB
		maxRequestSize = 1024 * 1024 * 1000) // 1 GB
public class Legel_case_entity extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public Legel_case_entity() {
		super();
		// TODO Auto-generated constructor stub
	}

	PrintWriter out = null;
	Connection con;
	PreparedStatement pst;
	HttpSession session = null;
	int row;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/plain;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try {

			out = response.getWriter();
			session = request.getSession(false);
			con = com.dbconnection.DB.getConnection();

			String folderName = "resources";
			String uploadPath = request.getServletContext().getRealPath("/") + folderName;
			System.out.println(uploadPath);
			File dir = new File(uploadPath);
			if (!dir.exists()) {
				dir.mkdirs();
			}

			Part file1 = request.getPart("photo");
			Random rand = new Random();

			// Generate random integers in range in 5 digit
			int uniqueID = rand.nextInt(100000);

			String kopid = request.getParameter("kopid");
			String name = request.getParameter("name");
			String bank = request.getParameter("bank");
			String place = request.getParameter("place");

			String state = request.getParameter("state");

			String date_of_fraud = request.getParameter("date_of_fraud");
			String nature_of_fraud = request.getParameter("nature_of_fraud");
			String noc = request.getParameter("noc");
			String amout_involved = request.getParameter("amout_involved");
			String ac = request.getParameter("ac");
			String amount_settled_by_csp = request.getParameter("amount_settled_by_csp");
			String amount_hold_by_bank = request.getParameter("amount_hold_by_bank");
			String amount_settled_by_nict = request.getParameter("amount_settled_by_nict");
			String amout_received_by_csp = request.getParameter("amout_received_by_csp");
			String hold_amout_received_by_bank = request.getParameter("hold_amout_received_by_bank");
			String fir_status = request.getParameter("fir_status");
			String crystallization_done = request.getParameter("crystallization_done");
			String case_status = request.getParameter("case_status");
			String date_of_ccommitee = request.getParameter("date_of_ccommitee");
			String chs = request.getParameter("chs");
			String crystallization_remarks = request.getParameter("crystallization_remarks");
			String remarks = request.getParameter("remarks");
			String photo = file1.getSubmittedFileName();
			String contact_person = request.getParameter("contact_person");
			String contact_person_s = request.getParameter("contact_person_s");
			String contact_person_t = request.getParameter("contact_person_t");
			String location = request.getParameter("location");
			String mobile = request.getParameter("mobile");
			String designation = request.getParameter("designation");

			String path1 = folderName + File.separator + photo;

			InputStream isNew = file1.getInputStream();
			Files.copy(isNew, Paths.get(uploadPath + File.separator + photo), StandardCopyOption.REPLACE_EXISTING);

			InputStream is1New = file1.getInputStream();
			Files.copy(is1New, Paths.get(uploadPath + File.separator + photo), StandardCopyOption.REPLACE_EXISTING);

			System.out.println("Hello");
			int status = 0;
			pst = con.prepareStatement(
					"insert into legal_case(uniqueID,kopid,name,bank,place,state,date_of_fraud,nature_of_fraud,noc,amount_involved,ac,amount_settled_by_csp,amount_hold_by_bank,amount_settled_by_nict,amout_received_by_csp,hold_amout_received_by_bank,fir_status,crystallization_done,case_status,date_of_ccommitee,chs,crystallization_remarks,remarks,photo,contact_person,contact_person_s,contact_person_t,location,mobile,designation)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			pst.setInt(1, uniqueID);
			pst.setString(2, kopid);
			pst.setString(3, name);
			pst.setString(4, bank);
			pst.setString(5, place);
			pst.setString(6, state);

			pst.setString(7, date_of_fraud);
			pst.setString(8, nature_of_fraud);
			pst.setString(9, noc);
			pst.setString(10, amout_involved);
			pst.setString(11, ac);
			pst.setString(12, amount_settled_by_csp);
			pst.setString(13, amount_hold_by_bank);
			pst.setString(14, amount_settled_by_nict);
			pst.setString(15, amout_received_by_csp);
			pst.setString(16, hold_amout_received_by_bank);

			pst.setString(17, fir_status);
			pst.setString(18, crystallization_done);
			pst.setString(19, case_status);
			pst.setString(20, date_of_ccommitee);
			pst.setString(21, chs);
			pst.setString(22, crystallization_remarks);
			pst.setString(23, remarks);
			pst.setString(24, photo);

			pst.setString(25, contact_person);
			pst.setString(26, contact_person_s);
			pst.setString(27, contact_person_t);
			pst.setString(28, location);
			pst.setString(29, mobile);
			pst.setString(30, designation);

			status = pst.executeUpdate();
			out.println("Record Added");
			response.sendRedirect("apicall.jsp");

			if (status > 0) {
				session.setAttribute("photo", photo);
				String msg9 = "" + photo + " Record upload successfully...";
				request.setAttribute("msg9", msg9);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String extractFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

}
