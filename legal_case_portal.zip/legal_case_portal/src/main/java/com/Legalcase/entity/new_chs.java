package com.Legalcase.entity;

import javax.servlet.http.HttpServlet;

public class new_chs extends HttpServlet {


}
