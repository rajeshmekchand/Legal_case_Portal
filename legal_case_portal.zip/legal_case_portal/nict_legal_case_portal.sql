-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nict_legal_case_portal
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `case_history`
--

DROP TABLE IF EXISTS `case_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_history` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `cs_id` int DEFAULT NULL,
  `new_chs` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`sno`),
  KEY `cs_id_idx` (`cs_id`),
  CONSTRAINT `cs_id` FOREIGN KEY (`cs_id`) REFERENCES `legal_case` (`cs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_history`
--

LOCK TABLES `case_history` WRITE;
/*!40000 ALTER TABLE `case_history` DISABLE KEYS */;
INSERT INTO `case_history` VALUES (1,40,'2024-01-26'),(2,39,'2024-01-19'),(3,40,'2024-01-27'),(4,42,'2024-01-11');
/*!40000 ALTER TABLE `case_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legal_case`
--

DROP TABLE IF EXISTS `legal_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legal_case` (
  `cs_id` int NOT NULL AUTO_INCREMENT,
  `uniqueID` varchar(45) DEFAULT NULL,
  `kopid` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `bank` varchar(45) DEFAULT NULL,
  `place` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `date_of_fraud` date DEFAULT NULL,
  `nature_of_fraud` varchar(45) DEFAULT NULL,
  `noc` varchar(45) DEFAULT NULL,
  `amount_involved` varchar(45) DEFAULT NULL,
  `ac` varchar(45) DEFAULT NULL,
  `amount_settled_by_csp` varchar(45) DEFAULT NULL,
  `amount_hold_by_bank` varchar(45) DEFAULT NULL,
  `amount_settled_by_nict` varchar(45) DEFAULT NULL,
  `amout_received_by_csp` varchar(45) CHARACTER SET armscii8 COLLATE armscii8_general_ci DEFAULT NULL,
  `hold_amout_received_by_bank` varchar(45) CHARACTER SET armscii8 COLLATE armscii8_general_ci DEFAULT NULL,
  `fir_status` varchar(45) DEFAULT NULL,
  `crystallization_done` varchar(45) DEFAULT NULL,
  `case_status` varchar(45) DEFAULT NULL,
  `date_of_ccommitee` varchar(45) DEFAULT NULL,
  `chs` datetime DEFAULT NULL,
  `crystallization_remarks` varchar(2000) DEFAULT NULL,
  `remarks` text,
  `photo` varchar(45) DEFAULT NULL,
  `contact_person` varchar(45) DEFAULT NULL,
  `contact_person_s` varchar(45) DEFAULT NULL,
  `contact_person_t` varchar(45) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `designation` varchar(45) DEFAULT NULL,
  `new_documents` varchar(45) DEFAULT NULL,
  `court_type` varchar(45) DEFAULT NULL,
  `case_number` varchar(45) DEFAULT NULL,
  `party_case` varchar(45) DEFAULT NULL,
  `new_chs` datetime DEFAULT NULL,
  PRIMARY KEY (`cs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legal_case`
--

LOCK TABLES `legal_case` WRITE;
/*!40000 ALTER TABLE `legal_case` DISABLE KEYS */;
INSERT INTO `legal_case` VALUES (32,'58f26080-702d-4411-b629-41ae96c468c4','ND021439-TPL-13997','Milind Yadav','state bank of india','Indore','MADHYA PRADESH','2023-12-18','deposit frauds','100','100','100','100','100','100','100','100','yes','yes','Ongoing','2023-12-15','2023-12-20 00:00:00','hello',NULL,'1688548747112.jpg','rajesh','himmat','shubam','bhopal','+917898709566','legal officer','1691459879863.jpg','tehsil ','789456','anupam singh','2023-12-29 00:00:00'),(33,'40185ae3-e21f-480f-b446-29a672268fa1','ND021439-TPL-13997','Milind Yadav','state bank of india','2023-12-24','MADHYA PRADESH','2023-12-18','deposit frauds, id fraud','100','100','100','100','100','100','100','100','yes','yes','Ongoing','2023-12-15','2023-12-24 00:00:00','hello',NULL,'','rajesh','himmat','shubam','bhopal','+917898709566','legal officer','test.jpg','high court','1234','himmat  sir','2023-12-24 00:00:00'),(38,'31305','ND021438-TPL-13947','Rajaram Chouhan','state bank of india','Dhar','MADHYA PRADESH','2023-12-14','RD ACCOUNTS FRAUD','12','35000','30000','33000','34000','25000','23000','','no','no','closed','2023-12-21','2023-12-31 00:00:00','hello','hello','FIR REAL.JPG','rajesh','himmat sir','nilesh sir','indore','7845126398','legal officer',NULL,NULL,NULL,NULL,NULL),(39,'14293','GJ055474-TPL-13951','SHAH SONALI JAYESHBHAI','panjab national bank','Ahmadabad','GUJARAT','2023-12-22','WITHDRAWAL FRAUD','10','45000','40000','38000','37000','36000','35000','','yes','yes','Ongoing','2023-12-28','2024-01-18 00:00:00','It seems like there might be a misunderstanding or a typo in your request. \"Loram 5\" doesn\'t appear to be a standard term or widely recognized concept in HTML or web development.','It seems like there might be a misunderstanding or a typo in your request. \"Loram 5\" doesn\'t appear to be a standard term or widely recognized concept in HTML or web development.','FIR REAL.JPG','srusti maam ','vajid sir','saloni','indore','9988774412','legal officer',NULL,NULL,NULL,NULL,NULL),(40,'95110','ND039435-TPL-14058','Dinesh Kumar','central bank of india','Ujjain','MADHYA PRADESH','2023-12-14','DEPOSIT FRAUD','78000','45600','45000','56600','5000','78450','12345','12345','yes','yes','Ongoing','2023-12-26','2024-01-04 00:00:00','Write, Run & Share HTML code online using OneCompiler\'s HTML online Code editor for free. It\'s one of the robust, feature-rich online Code editor for HTML language, running on the latest version HTML5. Getting started with the OneCompiler\'s HTML compiler is simple and pretty fast. The editor shows sample boilerplate code when you choose language as HTML. You can also specify the stylesheet information in styles.css tab and scripts information in scripts.js tab and start coding.','Write, Run & Share HTML code online using OneCompiler\'s HTML online Code editor for free. It\'s one of the robust, feature-rich online Code editor for HTML language, running on the latest version HTML5. Getting started with the OneCompiler\'s HTML compiler is simple and pretty fast. The editor shows sample boilerplate code when you choose language as HTML. You can also specify the stylesheet information in styles.css tab and scripts information in scripts.js tab and start coding.','FIR REAL.JPG','nilesh sir ','shubam sir ','aayush sir','indore','7548954212','legal officer',NULL,NULL,NULL,NULL,NULL),(41,'44308','MP022455-TPL-14086','ShriKrishna Prasad Singh','bank of baroda','Chhindwara','MADHYA PRADESH','2023-12-12','RD ACCOUNTS FRAUD','45','10000','9000','95000','85000','97000','96000','789455','no','no','closed','2023-12-21','2023-12-14 00:00:00','HTML element is everything present from start tag to end tag.The text present between start and end tag is called HTML element content.Anything can be a tagname but it\'s preferred to put the meaningful title to the content present as tag name.Do not forget the end tag.',NULL,'','hemangi ','harsh','vidhi','bhopal','7894561254','compline officer','1691459879863.jpg','tenshil','78945','anubhav bassi',NULL),(42,'12159','ND039435-TPL-14058','Dinesh Kumar','state bank of india','Ujjain','MADHYA PRADESH','2023-12-29','DEPOSIT FRAUD','789','456','789','789','456','789','123','789','yes','yes','Ongoing','2023-12-29','2023-12-27 00:00:00','What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','1691459879863.jpg','vajid khan','saloni jain','hemangi ','indore','7898709566','legal officer',NULL,NULL,NULL,NULL,NULL),(43,'42715','MP022450-TPL-14108','Manish Kumar Jain','state bank of  india','Katni','MADHYA PRADESH','2023-12-19','RD ACCOUNTS FRAUD','789','7895','4513','45614','4564','6784','456','','yes','no','closed','2023-12-23','2023-12-16 00:00:00','What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','1691459879863.jpg','saloni ','saloni','saloni','indore','788436','',NULL,NULL,NULL,NULL,NULL),(44,'67110','MP022450-TPL-14108','Manish Kumar Jain','state bank of  india','Katni','MADHYA PRADESH','2023-12-19','RD ACCOUNTS FRAUD','789','7895','4513','45614','4564','6784','456','','yes','no','closed','2023-12-23','2024-01-16 00:00:00','What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','1691459879863.jpg','saloni ','saloni','saloni','indore','78843645612','head',NULL,NULL,NULL,NULL,NULL),(45,'126','OR099387-TPL-12228','Biswabhusan Rout','panjab national bank','Puri','ODISHA','2023-12-15','WITHDRAWAL FRAUD,','45','78','1123','211','2231','12','12','12','no','no','closed','2023-12-22','2023-12-21 00:00:00','What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','unnamed.jpg','saloni','salani','ritu','indore','7889451226','ceo',NULL,NULL,NULL,NULL,NULL),(46,'19808','UP014171-TPL-13682','Lavlesh Kumar Singh','Central bank of india','Chitrakoot','UTTAR PRADESH','2023-12-29','DEPOSIT FRAUD','45','12','78','45','142','456','78','45','no','no','closed','2023-12-29','2024-01-03 00:00:00','heloo','hello','1691459879863.jpg','a','b','v','indore','7894561230','legal',NULL,NULL,NULL,NULL,NULL),(47,'67833','DL003201-TPL-12617','Avdhesh Kumar','sbi','Etah','NCT OF DELHI','2023-12-31','DEPOSIT FRAUD','2','2','2','2','2','2','2','2','no','no','closed','2023-12-28','2024-01-04 00:00:00','2','2','1691459879863.jpg','2','2','','3r','r','r',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `legal_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nature_of_fraud`
--

DROP TABLE IF EXISTS `nature_of_fraud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nature_of_fraud` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nature_of_fraudcol` varchar(45) DEFAULT NULL,
  `create` datetime DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nature_of_fraud`
--

LOCK TABLES `nature_of_fraud` WRITE;
/*!40000 ALTER TABLE `nature_of_fraud` DISABLE KEYS */;
/*!40000 ALTER TABLE `nature_of_fraud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operator_table`
--

DROP TABLE IF EXISTS `operator_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operator_table` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(45) DEFAULT NULL,
  `father_name` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `village` varchar(45) DEFAULT NULL,
  `tehsil` varchar(45) DEFAULT NULL,
  `district` varchar(45) DEFAULT NULL,
  `division` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operator_table`
--

LOCK TABLES `operator_table` WRITE;
/*!40000 ALTER TABLE `operator_table` DISABLE KEYS */;
INSERT INTO `operator_table` VALUES (1,'rajesh','mebb','gbg','fdg','fdgdf','dfg','fgf','Assam');
/*!40000 ALTER TABLE `operator_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `other_fraud_case`
--

DROP TABLE IF EXISTS `other_fraud_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `other_fraud_case` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uniqueID` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `bank` varchar(45) DEFAULT NULL,
  `place` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `legalnotice` varchar(45) DEFAULT NULL,
  `date_of_notice` varchar(45) DEFAULT NULL,
  `amount_involved` varchar(45) DEFAULT NULL,
  `amount_settled` varchar(45) DEFAULT NULL,
  `legal_notice_reply` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_fraud_case`
--

LOCK TABLES `other_fraud_case` WRITE;
/*!40000 ALTER TABLE `other_fraud_case` DISABLE KEYS */;
INSERT INTO `other_fraud_case` VALUES (2,'11030021','himmatsir','state bank of india','Indore','Goa','unnamed.jpg','2023-12-30','4545654','yes','yes'),(3,'87105618','Rajesh Mekchand','state bank of india','Indore','Madhya Pradesh','1688548747112.jpg','2023-12-30','4545654','yes','yes'),(4,'7211','aayush sir','state bank of india','Indore','Chhattisgarh','makwana ravi.png','2023-12-21','100','yes','yes'),(5,'6725','saloni gangrade','panjab national bank','khandawa','Madhya Pradesh','makwana ravi.png','2023-12-21','100','yes','yes'),(8,'3951','monika patidar','Bank of india','shajaur','Madhya Pradesh','test.jpg','2023-12-18','7000','yes','yes');
/*!40000 ALTER TABLE `other_fraud_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `other_fraud_login`
--

DROP TABLE IF EXISTS `other_fraud_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `other_fraud_login` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `mobileno` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_fraud_login`
--

LOCK TABLES `other_fraud_login` WRITE;
/*!40000 ALTER TABLE `other_fraud_login` DISABLE KEYS */;
INSERT INTO `other_fraud_login` VALUES (1,'Rajesh','7898709566');
/*!40000 ALTER TABLE `other_fraud_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `register`
--

LOCK TABLES `register` WRITE;
/*!40000 ALTER TABLE `register` DISABLE KEYS */;
INSERT INTO `register` VALUES (1,'NICT','1234'),(2,'Rajesh','456123'),(3,'RAJESH','123456');
/*!40000 ALTER TABLE `register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sdp_code`
--

DROP TABLE IF EXISTS `sdp_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sdp_code` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sdp_code` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sdp_code`
--

LOCK TABLES `sdp_code` WRITE;
/*!40000 ALTER TABLE `sdp_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `sdp_code` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-10 13:19:15
